from agents.judge_agent import EvaluateAgent
from summary_agent import SummaryAgent


ea = EvaluateAgent("What does section 475 of indian penal code state")
sa = SummaryAgent()

judge_output = ea.run(6)

text = sa.summarize_from_judge(judge_output)
print(text)

